#include <iostream>

using namespace std;

int main()
{
    cout << "max unsigned int = " << ((unsigned int) (-1)) << endl;
    cout << "max unsigned long = " << ((unsigned long) (-1)) << endl;
    cout << "max unsigned long long = " << ((unsigned long long) (-1)) << endl;
    return 0;
}
